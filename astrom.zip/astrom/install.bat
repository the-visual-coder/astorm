@echo off
echo Installing Astrom Antivirus dependencies...
pip install watchdog pystray pillow
echo.
echo Done! Run "python astrom.py" to launch Astrom.
pause
