"""
Astrom Antivirus - Real-Time Monitor
Uses watchdog to monitor filesystem changes and auto-scan new/modified files.
"""

import threading
from pathlib import Path

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    # Dummy base class so the code doesn't crash on import
    class FileSystemEventHandler:
        def dispatch(self, event): pass


class AstromEventHandler(FileSystemEventHandler):
    def __init__(self, scanner, on_threat_found=None):
        super().__init__()
        self.scanner = scanner
        self.on_threat_found = on_threat_found

    def on_created(self, event):
        if not event.is_directory:
            self._scan(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._scan(event.src_path)

    def _scan(self, path):
        result = self.scanner.scan_file(path)
        if result.status in ("threat", "suspicious"):
            if self.on_threat_found:
                self.on_threat_found(result)


class RealTimeMonitor:
    def __init__(self, scanner, on_threat_found=None):
        self.scanner = scanner
        self.on_threat_found = on_threat_found
        self.observer = None
        self.monitored_paths = []
        self.is_running = False

        if not WATCHDOG_AVAILABLE:
            print("[Astrom Monitor] watchdog not installed. Real-time monitoring disabled.")

    def start(self, paths):
        if not WATCHDOG_AVAILABLE:
            return False

        self.observer = Observer()
        self.monitored_paths = paths

        handler = AstromEventHandler(self.scanner, self.on_threat_found)
        for path in paths:
            if Path(path).exists():
                self.observer.schedule(handler, path, recursive=True)

        self.observer.start()
        self.is_running = True
        return True

    def stop(self):
        if self.observer and self.is_running:
            self.observer.stop()
            self.observer.join()
            self.is_running = False

    def add_path(self, path):
        """Dynamically add a new path to monitor."""
        if WATCHDOG_AVAILABLE and self.observer and Path(path).exists():
            handler = AstromEventHandler(self.scanner, self.on_threat_found)
            self.observer.schedule(handler, path, recursive=True)
            self.monitored_paths.append(path)
