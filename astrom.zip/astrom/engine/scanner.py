"""
Astrom Antivirus - Core Scanning Engine
Detection methods: Hash DB, Heuristics (multi-match), Entropy analysis
"""

import os
import math
import hashlib
import json
import shutil
import threading
from datetime import datetime
from pathlib import Path
from collections import Counter


KNOWN_MALWARE_HASHES = {
    "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f": "EICAR-Test-File",
}

SUSPICIOUS_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".scr", ".pif", ".com", ".vbs", ".vbe",
    ".js", ".jse", ".wsf", ".wsh", ".ps1", ".msi", ".hta", ".jar",
    ".reg", ".lnk"
}

# Trusted directories — anything inside these is never heuristic-scanned
def _build_trusted_dirs():
    dirs = set()
    for var, default in [
        ("PROGRAMFILES",      "C:\\Program Files"),
        ("PROGRAMFILES(X86)", "C:\\Program Files (x86)"),
        ("WINDIR",            "C:\\Windows"),
        ("SYSTEMROOT",        "C:\\Windows"),
        ("COMMONPROGRAMFILES","C:\\Program Files\\Common Files"),
    ]:
        val = os.environ.get(var, default)
        if val:
            dirs.add(val.lower().rstrip("\\") + "\\")
    # Always include these regardless of env vars
    dirs.update([
        "c:\\windows\\",
        "c:\\program files\\",
        "c:\\program files (x86)\\",
    ])
    return dirs

TRUSTED_DIRECTORIES = _build_trusted_dirs()

# Trusted filename patterns — filenames matching these are never flagged
TRUSTED_FILENAME_EXACT = {
    # Remote desktop
    "parsec.exe", "parsec-app.exe", "parsecapp.exe",
    # Browsers
    "chrome.exe", "firefox.exe", "msedge.exe", "opera.exe", "brave.exe",
    # Communication
    "discord.exe", "teams.exe", "zoom.exe", "slack.exe", "skype.exe",
    # Gaming
    "steam.exe", "epicgameslauncher.exe", "battle.net.exe", "origin.exe",
    "gameoverlayui.exe", "steamwebhelper.exe",
    # Dev tools
    "code.exe", "devenv.exe", "python.exe", "pythonw.exe", "node.exe",
    "git.exe", "cmd.exe", "powershell.exe", "pwsh.exe",
    # System
    "explorer.exe", "taskmgr.exe", "svchost.exe", "lsass.exe",
    "winlogon.exe", "csrss.exe", "wininit.exe", "services.exe",
    "spoolsv.exe", "msiexec.exe", "conhost.exe", "dllhost.exe",
    # Media / utilities
    "vlc.exe", "notepad++.exe", "7zfm.exe", "winrar.exe",
    # Common installer/updater names
    "uninst.exe", "uninstall.exe", "unins000.exe", "unins001.exe",
    "setup.exe", "installer.exe", "update.exe", "updater.exe",
    "autorun.exe",
}

# Trusted filename substrings — if any of these appear in the filename, skip heuristics
TRUSTED_FILENAME_CONTAINS = {
    "uninst", "uninstall", "setup", "install", "updater", "update",
    "devkit", "devkitpro", "redistributable", "vcredist", "directx",
}

# Multi-category heuristics — must match 2+ categories to flag
HEURISTIC_CATEGORIES = {
    "process_injection": [
        b"CreateRemoteThread", b"VirtualAllocEx", b"WriteProcessMemory",
        b"NtUnmapViewOfSection", b"SetThreadContext",
    ],
    "privilege_escalation": [
        b"SeDebugPrivilege", b"AdjustTokenPrivileges",
        b"net user /add", b"net localgroup administrators",
    ],
    "persistence": [
        b"CurrentVersion\\Run", b"CurrentVersion\\RunOnce",
        b"schtasks /create", b"sc create",
    ],
    "obfuscation": [
        b"powershell -enc", b"powershell -e ", b"powershell -nop",
        b"frombase64string", b"invoke-expression", b"iex(",
    ],
    "network_c2": [
        b"WebClient", b"DownloadFile", b"DownloadString",
        b"Net.WebRequest", b"curl http", b"wget http",
    ],
    "self_deletion": [
        b"cmd /c del", b"DeleteFileA", b"MoveFileEx",
    ],
}

HEURISTIC_CATEGORY_THRESHOLD = 2
ENTROPY_THRESHOLD = 7.2


class ScanResult:
    def __init__(self, filepath):
        self.filepath = str(filepath)
        self.status = "clean"
        self.threat_name = None
        self.detection_method = None
        self.timestamp = datetime.now().isoformat()
        self.file_hash = None
        self.details = []

    def to_dict(self):
        return {
            "filepath": self.filepath,
            "status": self.status,
            "threat_name": self.threat_name,
            "detection_method": self.detection_method,
            "timestamp": self.timestamp,
            "file_hash": self.file_hash,
            "details": self.details,
        }


class AstromScanner:
    def __init__(self, definitions_path="definitions", quarantine_path="quarantine", log_path="logs"):
        self.definitions_path = Path(definitions_path)
        self.quarantine_path = Path(quarantine_path)
        self.log_path = Path(log_path)

        self.quarantine_path.mkdir(exist_ok=True)
        self.log_path.mkdir(exist_ok=True)
        self.definitions_path.mkdir(exist_ok=True)

        self.malware_hashes = dict(KNOWN_MALWARE_HASHES)
        self.whitelist_hashes = set()
        self._load_definitions()

        self.scan_count = 0
        self.threat_count = 0
        self.is_scanning = False
        self._stop_event = threading.Event()
        self.on_file_scanned = None
        self.on_scan_complete = None

    def _load_definitions(self):
        hash_file = self.definitions_path / "hashes.json"
        if hash_file.exists():
            try:
                with open(hash_file, "r") as f:
                    data = json.load(f)
                    self.malware_hashes.update(data)
            except Exception:
                pass
        whitelist_file = self.definitions_path / "whitelist.json"
        if whitelist_file.exists():
            try:
                with open(whitelist_file, "r") as f:
                    self.whitelist_hashes = set(json.load(f))
            except Exception:
                pass

    def _compute_hash(self, filepath):
        h = hashlib.sha256()
        try:
            with open(filepath, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except (PermissionError, OSError):
            return None

    def _compute_entropy(self, data):
        if not data:
            return 0.0
        counts = Counter(data)
        total = len(data)
        return -sum((c / total) * math.log2(c / total) for c in counts.values())

    def _is_trusted(self, filepath):
        fp = str(filepath).lower().replace("/", "\\")
        fname = Path(filepath).name.lower()

        # Exact filename match
        if fname in TRUSTED_FILENAME_EXACT:
            return True

        # Filename contains a trusted keyword (e.g. "uninst", "updater")
        fname_no_ext = Path(fname).stem
        for keyword in TRUSTED_FILENAME_CONTAINS:
            if keyword in fname_no_ext:
                return True

        # File lives inside a trusted directory
        for td in TRUSTED_DIRECTORIES:
            if fp.startswith(td):
                return True

        # Also trust anything in user's whitelisted hashes
        return False

    def _check_heuristics(self, filepath):
        try:
            with open(filepath, "rb") as f:
                content = f.read(2_000_000)
            content_lower = content.lower()
        except (PermissionError, OSError):
            return [], []

        matched_categories = []
        matched_patterns = []
        for category, patterns in HEURISTIC_CATEGORIES.items():
            hits = [p.decode(errors="replace") for p in patterns if p.lower() in content_lower]
            if hits:
                matched_categories.append(category)
                matched_patterns.extend(hits[:2])
        return matched_categories, matched_patterns

    def _check_entropy(self, filepath):
        try:
            with open(filepath, "rb") as f:
                data = f.read(1_000_000)
            if data[:2] != b"MZ":
                return None
            entropy = self._compute_entropy(data)
            if entropy >= ENTROPY_THRESHOLD:
                return round(entropy, 3)
        except (PermissionError, OSError):
            pass
        return None

    def scan_file(self, filepath) -> ScanResult:
        filepath = Path(filepath)
        result = ScanResult(filepath)

        if not filepath.exists() or not filepath.is_file():
            result.status = "error"
            result.threat_name = "File not found"
            return result

        file_hash = self._compute_hash(filepath)
        result.file_hash = file_hash

        if file_hash:
            if file_hash in self.whitelist_hashes:
                self.scan_count += 1
                return result
            if file_hash in self.malware_hashes:
                result.status = "threat"
                result.threat_name = self.malware_hashes[file_hash]
                result.detection_method = "hash_signature"
                self.threat_count += 1
                self._log_threat(result)
                return result

        if self._is_trusted(filepath):
            self.scan_count += 1
            return result

        if filepath.suffix.lower() in SUSPICIOUS_EXTENSIONS:
            categories, patterns = self._check_heuristics(filepath)
            if len(categories) >= HEURISTIC_CATEGORY_THRESHOLD:
                result.status = "suspicious"
                result.threat_name = f"Heuristic.{'.'.join(categories[:2])}"
                result.detection_method = "heuristic"
                result.details = patterns
                self.threat_count += 1
                self._log_threat(result)
                return result

            entropy = self._check_entropy(filepath)
            if entropy:
                result.status = "suspicious"
                result.threat_name = f"Packed.HighEntropy ({entropy})"
                result.detection_method = "entropy"
                result.details = [f"Shannon entropy: {entropy}"]
                self.threat_count += 1
                self._log_threat(result)
                return result

        self.scan_count += 1
        return result

    def scan_directory(self, directory, recursive=True):
        self.is_scanning = True
        self._stop_event.clear()
        results = []
        directory = Path(directory)
        try:
            walker = directory.rglob("*") if recursive else directory.glob("*")
            for path in walker:
                if self._stop_event.is_set():
                    break
                if path.is_file():
                    result = self.scan_file(path)
                    results.append(result)
                    if self.on_file_scanned:
                        self.on_file_scanned(result)
        except PermissionError:
            pass
        self.is_scanning = False
        summary = {
            "total_scanned": len(results),
            "threats": [r.to_dict() for r in results if r.status in ("threat", "suspicious")],
            "threat_count": sum(1 for r in results if r.status in ("threat", "suspicious")),
        }
        if self.on_scan_complete:
            self.on_scan_complete(summary)
        return summary

    def stop_scan(self):
        self._stop_event.set()
        self.is_scanning = False

    def quarantine_file(self, filepath):
        filepath = Path(filepath)
        dest = self.quarantine_path / (filepath.stem + "_" + filepath.suffix[1:] + ".quarantine")
        try:
            shutil.move(str(filepath), str(dest))
            meta = {"original_path": str(filepath), "quarantined_at": datetime.now().isoformat()}
            with open(str(dest) + ".meta", "w") as f:
                json.dump(meta, f)
            return True, str(dest)
        except Exception as e:
            return False, str(e)

    def restore_file(self, quarantine_path):
        meta_path = quarantine_path + ".meta"
        try:
            with open(meta_path, "r") as f:
                meta = json.load(f)
            original = meta["original_path"]
            shutil.move(quarantine_path, original)
            os.remove(meta_path)
            return True, original
        except Exception as e:
            return False, str(e)

    def delete_quarantined(self, quarantine_path):
        try:
            os.remove(quarantine_path)
            meta = quarantine_path + ".meta"
            if os.path.exists(meta):
                os.remove(meta)
            return True
        except Exception as e:
            return False

    def whitelist_file(self, filepath):
        h = self._compute_hash(filepath)
        if h:
            self.whitelist_hashes.add(h)
            wl_file = self.definitions_path / "whitelist.json"
            with open(wl_file, "w") as f:
                json.dump(list(self.whitelist_hashes), f)
            return True
        return False

    def get_quarantine_list(self):
        items = []
        for f in self.quarantine_path.glob("*.quarantine"):
            meta_path = str(f) + ".meta"
            original = "Unknown"
            quarantined_at = ""
            if os.path.exists(meta_path):
                try:
                    with open(meta_path) as mf:
                        meta = json.load(mf)
                    original = meta.get("original_path", "Unknown")
                    quarantined_at = meta.get("quarantined_at", "")
                except Exception:
                    pass
            items.append({
                "quarantine_path": str(f),
                "original_path": original,
                "filename": Path(original).name,
                "quarantined_at": quarantined_at,
            })
        return items

    def _log_threat(self, result: ScanResult):
        log_file = self.log_path / "threats.log"
        with open(log_file, "a") as f:
            f.write(json.dumps(result.to_dict()) + "\n")

    def get_threat_log(self):
        log_file = self.log_path / "threats.log"
        threats = []
        if log_file.exists():
            with open(log_file, "r") as f:
                for line in f:
                    try:
                        threats.append(json.loads(line.strip()))
                    except Exception:
                        pass
        return threats
