@echo off
cd /d "%~dp0"
start pythonw astrom.py
