"""
Astrom Antivirus - Main GUI + System Tray
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import sys
import os
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from engine.scanner import AstromScanner
from engine.monitor import RealTimeMonitor

# Try system tray
try:
    import pystray
    from PIL import Image, ImageDraw
    TRAY_AVAILABLE = True
except ImportError:
    TRAY_AVAILABLE = False

BG_DARK   = "#0a0c10"
BG_PANEL  = "#0f1318"
BG_CARD   = "#141920"
ACCENT    = "#00e5ff"
ACCENT2   = "#0091b5"
GREEN     = "#00ff88"
RED       = "#ff3d5a"
YELLOW    = "#ffd600"
TEXT_MAIN = "#e8f4f8"
TEXT_DIM  = "#4a6070"
TEXT_MID  = "#8aa8b8"
BORDER    = "#1e2d38"


def make_tray_icon():
    """Generate a simple icon image for the system tray."""
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Hexagon-ish shield shape
    draw.ellipse([4, 4, 60, 60], fill=(0, 229, 255, 255))
    draw.ellipse([12, 12, 52, 52], fill=(10, 12, 16, 255))
    draw.text((20, 22), "A", fill=(0, 229, 255, 255))
    return img


class AstromApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Astrom Antivirus")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=BG_DARK)

        base = Path(__file__).parent.parent
        self.scanner = AstromScanner(
            definitions_path=str(base / "definitions"),
            quarantine_path=str(base / "quarantine"),
            log_path=str(base / "logs"),
        )
        self.scanner.on_file_scanned = self._on_file_scanned
        self.scanner.on_scan_complete = self._on_scan_complete
        self.monitor = RealTimeMonitor(self.scanner, on_threat_found=self._on_realtime_threat)

        self._scan_thread = None
        self._scanned_files = 0
        self._tray_icon = None

        self._build_ui()
        self._show_page("dashboard")
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        if TRAY_AVAILABLE:
            self._start_tray()

    # ── Tray ──────────────────────────────────────────────────────────────────

    def _start_tray(self):
        icon_img = make_tray_icon()
        menu = pystray.Menu(
            pystray.MenuItem("Open Astrom", self._tray_open, default=True),
            pystray.MenuItem("Quick Scan", lambda: self.after(0, lambda: self._start_scan("quick"))),
            pystray.MenuItem("Toggle Monitor", lambda: self.after(0, self._toggle_monitor)),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Exit", self._tray_exit),
        )
        self._tray_icon = pystray.Icon("Astrom", icon_img, "Astrom Antivirus", menu)
        threading.Thread(target=self._tray_icon.run, daemon=True).start()

    def _tray_open(self, icon=None, item=None):
        self.after(0, self.deiconify)
        self.after(0, self.lift)

    def _tray_exit(self, icon=None, item=None):
        if self._tray_icon:
            self._tray_icon.stop()
        self.after(0, self._shutdown)

    def _on_close(self):
        """Minimize to tray instead of closing."""
        if TRAY_AVAILABLE and self._tray_icon:
            self.withdraw()
        else:
            self._shutdown()

    def _shutdown(self):
        self.monitor.stop()
        self.scanner.stop_scan()
        self.destroy()

    # ── UI Builder ────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.sidebar = tk.Frame(self, bg=BG_PANEL, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        self._build_sidebar()

        self.content = tk.Frame(self, bg=BG_DARK)
        self.content.pack(side="right", fill="both", expand=True)

        self.pages = {}
        self._build_dashboard()
        self._build_scan_page()
        self._build_quarantine_page()
        self._build_log_page()
        self._build_settings_page()

    def _build_sidebar(self):
        logo_frame = tk.Frame(self.sidebar, bg=BG_PANEL, pady=24)
        logo_frame.pack(fill="x")
        tk.Label(logo_frame, text="⬡", font=("Courier", 28), fg=ACCENT, bg=BG_PANEL).pack()
        tk.Label(logo_frame, text="ASTROM", font=("Courier", 16, "bold"), fg=TEXT_MAIN, bg=BG_PANEL).pack()
        tk.Label(logo_frame, text="ANTIVIRUS", font=("Courier", 7), fg=TEXT_DIM, bg=BG_PANEL).pack()
        tk.Frame(self.sidebar, bg=BORDER, height=1).pack(fill="x", padx=16)

        self.nav_buttons = {}
        nav_items = [
            ("dashboard",  "⬡  Dashboard"),
            ("scan",       "⊕  Scan"),
            ("quarantine", "⊘  Quarantine"),
            ("log",        "≡  Threat Log"),
            ("settings",   "⚙  Settings"),
        ]
        nav_frame = tk.Frame(self.sidebar, bg=BG_PANEL, pady=12)
        nav_frame.pack(fill="x")
        for key, label in nav_items:
            btn = tk.Button(nav_frame, text=label, anchor="w",
                font=("Courier", 10), fg=TEXT_MID, bg=BG_PANEL,
                activeforeground=ACCENT, activebackground=BG_PANEL,
                relief="flat", bd=0, padx=20, pady=10, cursor="hand2",
                command=lambda k=key: self._show_page(k))
            btn.pack(fill="x")
            self.nav_buttons[key] = btn

        tk.Frame(self.sidebar, bg=BG_PANEL).pack(fill="both", expand=True)
        tk.Frame(self.sidebar, bg=BORDER, height=1).pack(fill="x", padx=16)
        status_frame = tk.Frame(self.sidebar, bg=BG_PANEL, pady=16)
        status_frame.pack(fill="x")
        self.monitor_status_label = tk.Label(status_frame, text="● MONITOR OFF",
            font=("Courier", 8), fg=RED, bg=BG_PANEL)
        self.monitor_status_label.pack(padx=20, anchor="w")
        self.engine_label = tk.Label(status_frame,
            text=f"Signatures: {len(self.scanner.malware_hashes)}",
            font=("Courier", 8), fg=TEXT_DIM, bg=BG_PANEL)
        self.engine_label.pack(padx=20, anchor="w")
        if TRAY_AVAILABLE:
            tk.Label(status_frame, text="● Tray active",
                font=("Courier", 8), fg=GREEN, bg=BG_PANEL).pack(padx=20, anchor="w")

    # ── Dashboard ─────────────────────────────────────────────────────────────

    def _build_dashboard(self):
        page = tk.Frame(self.content, bg=BG_DARK)
        self.pages["dashboard"] = page

        hdr = tk.Frame(page, bg=BG_DARK, pady=28, padx=32)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Dashboard", font=("Courier", 20, "bold"), fg=TEXT_MAIN, bg=BG_DARK).pack(anchor="w")
        tk.Label(hdr, text=datetime.now().strftime("%A, %B %d %Y"),
            font=("Courier", 9), fg=TEXT_DIM, bg=BG_DARK).pack(anchor="w")

        cards_frame = tk.Frame(page, bg=BG_DARK, padx=32)
        cards_frame.pack(fill="x")
        self.stat_vars = {
            "threats":    tk.StringVar(value="0"),
            "scanned":    tk.StringVar(value="0"),
            "quarantine": tk.StringVar(value="0"),
            "status":     tk.StringVar(value="Protected"),
        }
        card_defs = [
            ("Threats Found",  "threats",    RED),
            ("Files Scanned",  "scanned",    ACCENT),
            ("Quarantined",    "quarantine", YELLOW),
            ("System Status",  "status",     GREEN),
        ]
        for i, (label, key, color) in enumerate(card_defs):
            card = tk.Frame(cards_frame, bg=BG_CARD)
            card.grid(row=0, column=i, padx=6, sticky="nsew")
            cards_frame.columnconfigure(i, weight=1)
            tk.Frame(card, bg=color, height=3).pack(fill="x")
            tk.Label(card, textvariable=self.stat_vars[key],
                font=("Courier", 26, "bold"), fg=color, bg=BG_CARD, pady=12).pack()
            tk.Label(card, text=label, font=("Courier", 8), fg=TEXT_DIM, bg=BG_CARD, pady=6).pack()

        qa = tk.Frame(page, bg=BG_DARK, padx=32, pady=20)
        qa.pack(fill="x")
        tk.Label(qa, text="QUICK ACTIONS", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_DARK).pack(anchor="w", pady=(0,8))
        btns = tk.Frame(qa, bg=BG_DARK)
        btns.pack(anchor="w")
        self._make_btn(btns, "⊕  Quick Scan", ACCENT, lambda: self._start_scan("quick")).pack(side="left", padx=(0,8))
        self._make_btn(btns, "⬡  Full Scan", ACCENT2, lambda: self._start_scan("full")).pack(side="left", padx=(0,8))
        self._monitor_btn = self._make_btn(btns, "●  Start Monitor", GREEN, self._toggle_monitor)
        self._monitor_btn.pack(side="left")

        rt = tk.Frame(page, bg=BG_DARK, padx=32, pady=10)
        rt.pack(fill="both", expand=True)
        tk.Label(rt, text="RECENT THREATS", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_DARK).pack(anchor="w", pady=(0,8))
        self.recent_tree = self._make_tree(rt,
            columns=("time", "file", "threat", "method"),
            headings=("Time", "File", "Threat", "Method"))
        self.recent_tree.pack(fill="both", expand=True)

    # ── Scan Page ─────────────────────────────────────────────────────────────

    def _build_scan_page(self):
        page = tk.Frame(self.content, bg=BG_DARK)
        self.pages["scan"] = page

        hdr = tk.Frame(page, bg=BG_DARK, pady=28, padx=32)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Scanner", font=("Courier", 20, "bold"), fg=TEXT_MAIN, bg=BG_DARK).pack(anchor="w")

        opts = tk.Frame(page, bg=BG_DARK, padx=32)
        opts.pack(fill="x")
        self._make_btn(opts, " Quick Scan\n(Common Locations)", ACCENT,
            lambda: self._start_scan("quick")).pack(side="left", padx=(0,8), ipady=4)
        self._make_btn(opts, " Full Scan\n(Entire C: Drive)", ACCENT2,
            lambda: self._start_scan("full")).pack(side="left", padx=(0,8), ipady=4)
        self._make_btn(opts, " Custom Scan\n(Choose Folder)", TEXT_MID,
            lambda: self._start_scan("custom")).pack(side="left", ipady=4)

        prog = tk.Frame(page, bg=BG_CARD, padx=24, pady=18)
        prog.pack(fill="x", padx=32, pady=16)
        self.scan_status_label = tk.Label(prog, text="Ready to scan.",
            font=("Courier", 10), fg=TEXT_MID, bg=BG_CARD)
        self.scan_status_label.pack(anchor="w")
        self.progress_var = tk.DoubleVar(value=0)
        ttk.Progressbar(prog, variable=self.progress_var, maximum=100).pack(fill="x", pady=8)
        self.scan_counter_label = tk.Label(prog, text="",
            font=("Courier", 8), fg=TEXT_DIM, bg=BG_CARD)
        self.scan_counter_label.pack(anchor="w")
        ctrl = tk.Frame(prog, bg=BG_CARD)
        ctrl.pack(anchor="w", pady=(8,0))
        self.stop_btn = self._make_btn(ctrl, "⊘  Stop Scan", RED, self._stop_scan)
        self.stop_btn.pack(side="left")
        self.stop_btn.config(state="disabled")

        res = tk.Frame(page, bg=BG_DARK, padx=32)
        res.pack(fill="both", expand=True, pady=(0,16))
        tk.Label(res, text="SCAN RESULTS", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_DARK).pack(anchor="w", pady=(0,8))
        self.scan_tree = self._make_tree(res,
            columns=("status", "file", "threat", "method"),
            headings=("Status", "File", "Threat", "Method"))
        self.scan_tree.pack(fill="both", expand=True)
        self.scan_tree.bind("<Double-1>", self._on_scan_item_dclick)

        # Right-click menu
        self.scan_menu = tk.Menu(self, tearoff=0, bg=BG_CARD, fg=TEXT_MAIN,
            activebackground=ACCENT2, activeforeground=BG_DARK)
        self.scan_menu.add_command(label="Quarantine File", command=self._ctx_quarantine)
        self.scan_menu.add_command(label="Whitelist File (Never Flag Again)", command=self._ctx_whitelist)
        self.scan_tree.bind("<Button-3>", self._show_scan_menu)

    # ── Quarantine Page ───────────────────────────────────────────────────────

    def _build_quarantine_page(self):
        page = tk.Frame(self.content, bg=BG_DARK)
        self.pages["quarantine"] = page
        hdr = tk.Frame(page, bg=BG_DARK, pady=28, padx=32)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Quarantine", font=("Courier", 20, "bold"), fg=TEXT_MAIN, bg=BG_DARK).pack(anchor="w")
        tk.Label(hdr, text="Isolated threats — safe from execution",
            font=("Courier", 9), fg=TEXT_DIM, bg=BG_DARK).pack(anchor="w")

        btns = tk.Frame(page, bg=BG_DARK, padx=32)
        btns.pack(fill="x", pady=(0,12))
        self._make_btn(btns, "↺  Refresh", ACCENT, self._refresh_quarantine).pack(side="left", padx=(0,8))
        self._make_btn(btns, "↩  Restore Selected", YELLOW, self._restore_quarantined).pack(side="left", padx=(0,8))
        self._make_btn(btns, "⊘  Delete Selected", RED, self._delete_quarantined).pack(side="left")

        q = tk.Frame(page, bg=BG_DARK, padx=32)
        q.pack(fill="both", expand=True)
        self.quarantine_tree = self._make_tree(q,
            columns=("filename", "original", "date"),
            headings=("Filename", "Original Path", "Quarantined At"))
        self.quarantine_tree.pack(fill="both", expand=True)
        self._refresh_quarantine()

    # ── Log Page ──────────────────────────────────────────────────────────────

    def _build_log_page(self):
        page = tk.Frame(self.content, bg=BG_DARK)
        self.pages["log"] = page
        hdr = tk.Frame(page, bg=BG_DARK, pady=28, padx=32)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Threat Log", font=("Courier", 20, "bold"), fg=TEXT_MAIN, bg=BG_DARK).pack(anchor="w")
        btns = tk.Frame(page, bg=BG_DARK, padx=32)
        btns.pack(fill="x", pady=(0,12))
        self._make_btn(btns, "↺  Refresh", ACCENT, self._refresh_log).pack(side="left")
        lf = tk.Frame(page, bg=BG_DARK, padx=32)
        lf.pack(fill="both", expand=True)
        self.log_tree = self._make_tree(lf,
            columns=("time", "file", "threat", "method", "hash"),
            headings=("Time", "File", "Threat", "Method", "Hash"))
        self.log_tree.pack(fill="both", expand=True)
        self._refresh_log()

    # ── Settings Page ─────────────────────────────────────────────────────────

    def _build_settings_page(self):
        page = tk.Frame(self.content, bg=BG_DARK)
        self.pages["settings"] = page
        hdr = tk.Frame(page, bg=BG_DARK, pady=28, padx=32)
        hdr.pack(fill="x")
        tk.Label(hdr, text="Settings", font=("Courier", 20, "bold"), fg=TEXT_MAIN, bg=BG_DARK).pack(anchor="w")

        # Monitor paths
        s1 = tk.Frame(page, bg=BG_CARD, padx=24, pady=18)
        s1.pack(fill="x", padx=32, pady=(0,12))
        tk.Label(s1, text="REAL-TIME MONITOR PATHS", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", pady=(0,8))
        self.monitor_paths_var = tk.StringVar(value=r"C:\Users;C:\Downloads;C:\Temp")
        tk.Entry(s1, textvariable=self.monitor_paths_var,
            font=("Courier", 9), bg=BG_DARK, fg=TEXT_MAIN,
            insertbackground=ACCENT, relief="flat", bd=4).pack(fill="x")
        tk.Label(s1, text="Separate paths with semicolons (;)",
            font=("Courier", 8), fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", pady=(4,0))

        # Scan options
        s2 = tk.Frame(page, bg=BG_CARD, padx=24, pady=18)
        s2.pack(fill="x", padx=32, pady=(0,12))
        tk.Label(s2, text="SCAN OPTIONS", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", pady=(0,8))
        self.heuristics_var = tk.BooleanVar(value=True)
        self.recursive_var = tk.BooleanVar(value=True)
        for var, text in [(self.heuristics_var, "Enable heuristic scanning"),
                          (self.recursive_var, "Scan subdirectories recursively")]:
            tk.Checkbutton(s2, text=text, variable=var,
                font=("Courier", 9), fg=TEXT_MAIN, bg=BG_CARD,
                activebackground=BG_CARD, selectcolor=BG_DARK).pack(anchor="w")

        # Whitelist manager
        s3 = tk.Frame(page, bg=BG_CARD, padx=24, pady=18)
        s3.pack(fill="x", padx=32, pady=(0,12))
        tk.Label(s3, text="WHITELIST A FILE", font=("Courier", 9, "bold"), fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", pady=(0,8))
        tk.Label(s3, text="Whitelisted files are never flagged, even if they match heuristics.",
            font=("Courier", 8), fg=TEXT_DIM, bg=BG_CARD).pack(anchor="w", pady=(0,8))
        self._make_btn(s3, "Browse & Whitelist File", YELLOW, self._browse_whitelist).pack(anchor="w")

        self._make_btn(page, "  Save Settings  ", ACCENT,
            lambda: messagebox.showinfo("Astrom", "Settings saved.")).pack(anchor="w", padx=32, pady=8)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _make_btn(self, parent, text, color, command):
        return tk.Button(parent, text=text, font=("Courier", 9, "bold"),
            fg=BG_DARK, bg=color, activeforeground=BG_DARK,
            activebackground=color, relief="flat", bd=0,
            padx=14, pady=7, cursor="hand2", command=command)

    def _make_tree(self, parent, columns, headings):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Astrom.Treeview", background=BG_CARD, foreground=TEXT_MAIN,
            fieldbackground=BG_CARD, rowheight=28, font=("Courier", 9))
        style.configure("Astrom.Treeview.Heading", background=BG_PANEL, foreground=TEXT_DIM,
            font=("Courier", 8, "bold"), relief="flat")
        style.map("Astrom.Treeview",
            background=[("selected", ACCENT2)], foreground=[("selected", BG_DARK)])

        tree = ttk.Treeview(parent, columns=columns, show="headings", style="Astrom.Treeview")
        for col, head in zip(columns, headings):
            tree.heading(col, text=head)
            tree.column(col, width=160, anchor="w")
        sb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        return tree

    def _show_page(self, name):
        for page in self.pages.values():
            page.pack_forget()
        self.pages[name].pack(fill="both", expand=True)
        for key, btn in self.nav_buttons.items():
            btn.config(fg=ACCENT if key == name else TEXT_MID,
                       bg=BG_CARD if key == name else BG_PANEL)

    # ── Scan Logic ────────────────────────────────────────────────────────────

    def _start_scan(self, mode):
        if self.scanner.is_scanning:
            return
        if mode == "custom":
            path = filedialog.askdirectory(title="Select folder to scan")
            if not path:
                return
            paths = [path]
        elif mode == "quick":
            home = str(Path.home())
            paths = [os.path.join(home, d) for d in ("Downloads", "Desktop", "Documents")]
            paths += [os.environ.get("TEMP", "C:\\Temp")]
            paths = [p for p in paths if os.path.exists(p)]
        else:
            paths = ["C:\\"]

        for item in self.scan_tree.get_children():
            self.scan_tree.delete(item)
        self.progress_var.set(0)
        self.scan_status_label.config(text="Scanning…", fg=ACCENT)
        self.stop_btn.config(state="normal")
        self._scanned_files = 0
        self._show_page("scan")

        def run():
            for path in paths:
                if self._stop_event_check():
                    break
                self.scanner.scan_directory(path, recursive=self.recursive_var.get())

        self._scan_thread = threading.Thread(target=run, daemon=True)
        self._scan_thread.start()

    def _stop_event_check(self):
        return not self.scanner.is_scanning and self._scanned_files > 0

    def _stop_scan(self):
        self.scanner.stop_scan()
        self.scan_status_label.config(text="Scan stopped.", fg=YELLOW)
        self.stop_btn.config(state="disabled")

    def _on_file_scanned(self, result):
        self._scanned_files += 1
        self.after(0, self._update_scan_ui, result)

    def _update_scan_ui(self, result):
        self.scan_counter_label.config(
            text=f"{self._scanned_files} files scanned  ·  {self.scanner.threat_count} threats found")
        self.stat_vars["scanned"].set(str(self._scanned_files))
        self.stat_vars["threats"].set(str(self.scanner.threat_count))
        p = min(self.progress_var.get() + 0.05, 99)
        self.progress_var.set(p)

        if result.status in ("threat", "suspicious"):
            tag = result.status
            self.scan_tree.insert("", 0, values=(
                result.status.upper(),
                Path(result.filepath).name,
                result.threat_name or "",
                result.detection_method or "",
            ), tags=(tag,))
            self.scan_tree.tag_configure("threat", foreground=RED)
            self.scan_tree.tag_configure("suspicious", foreground=YELLOW)
            self.recent_tree.insert("", 0, values=(
                datetime.now().strftime("%H:%M:%S"),
                Path(result.filepath).name,
                result.threat_name or "",
                result.detection_method or "",
            ))

    def _on_scan_complete(self, summary):
        self.after(0, self._finalize_scan, summary)

    def _finalize_scan(self, summary):
        self.progress_var.set(100)
        tc = summary["threat_count"]
        self.scan_status_label.config(
            text=f"Scan complete — {summary['total_scanned']} files scanned, {tc} threat(s) found.",
            fg=GREEN if tc == 0 else RED)
        self.stop_btn.config(state="disabled")
        self.stat_vars["status"].set("Protected" if tc == 0 else "At Risk")

    # ── Monitor ───────────────────────────────────────────────────────────────

    def _toggle_monitor(self):
        if self.monitor.is_running:
            self.monitor.stop()
            self.monitor_status_label.config(text="● MONITOR OFF", fg=RED)
            self._monitor_btn.config(text="●  Start Monitor", bg=GREEN)
        else:
            paths = [p.strip() for p in self.monitor_paths_var.get().split(";") if p.strip()]
            started = self.monitor.start(paths)
            if started:
                self.monitor_status_label.config(text="● MONITOR ON", fg=GREEN)
                self._monitor_btn.config(text="⊘  Stop Monitor", bg=RED)
            else:
                messagebox.showwarning("Astrom", "watchdog not installed.\nRun: pip install watchdog")

    def _on_realtime_threat(self, result):
        self.after(0, self._alert_threat, result)

    def _alert_threat(self, result):
        self.scanner.threat_count += 1
        self.stat_vars["threats"].set(str(self.scanner.threat_count))
        self.stat_vars["status"].set("At Risk")
        messagebox.showwarning("⚠ Astrom — Threat Detected",
            f"Threat: {result.threat_name}\nFile: {result.filepath}\nMethod: {result.detection_method}\n\nGo to Quarantine to isolate this file.")

    # ── Right-click actions ───────────────────────────────────────────────────

    def _show_scan_menu(self, event):
        item = self.scan_tree.identify_row(event.y)
        if item:
            self.scan_tree.selection_set(item)
            self.scan_menu.post(event.x_root, event.y_root)

    def _get_selected_scan_filepath(self):
        item = self.scan_tree.focus()
        if not item:
            return None
        vals = self.scan_tree.item(item)["values"]
        if not vals:
            return None
        threats = self.scanner.get_threat_log()
        match = next((t for t in reversed(threats) if Path(t["filepath"]).name == str(vals[1])), None)
        return match["filepath"] if match else None

    def _ctx_quarantine(self):
        fp = self._get_selected_scan_filepath()
        if not fp:
            return
        ok, dest = self.scanner.quarantine_file(fp)
        if ok:
            messagebox.showinfo("Astrom", f"Quarantined:\n{dest}")
            self._refresh_quarantine()
        else:
            messagebox.showerror("Astrom", f"Failed:\n{dest}")

    def _ctx_whitelist(self):
        fp = self._get_selected_scan_filepath()
        if not fp:
            return
        if self.scanner.whitelist_file(fp):
            messagebox.showinfo("Astrom", f"Whitelisted — will never be flagged again:\n{fp}")
        else:
            messagebox.showerror("Astrom", "Could not whitelist file.")

    def _on_scan_item_dclick(self, event):
        self._ctx_quarantine()

    def _browse_whitelist(self):
        path = filedialog.askopenfilename(title="Select file to whitelist")
        if path and self.scanner.whitelist_file(path):
            messagebox.showinfo("Astrom", f"Whitelisted:\n{path}")

    # ── Quarantine ────────────────────────────────────────────────────────────

    def _refresh_quarantine(self):
        for item in self.quarantine_tree.get_children():
            self.quarantine_tree.delete(item)
        items = self.scanner.get_quarantine_list()
        for item in items:
            self.quarantine_tree.insert("", "end", values=(
                item["filename"],
                item["original_path"],
                item["quarantined_at"][:19] if item["quarantined_at"] else "",
            ))
        self.stat_vars["quarantine"].set(str(len(items)))

    def _restore_quarantined(self):
        selected = self.quarantine_tree.selection()
        if not selected:
            return
        for s in selected:
            vals = self.quarantine_tree.item(s)["values"]
            # Find matching quarantine item
            items = self.scanner.get_quarantine_list()
            match = next((i for i in items if i["filename"] == str(vals[0])), None)
            if match:
                ok, result = self.scanner.restore_file(match["quarantine_path"])
                if ok:
                    messagebox.showinfo("Astrom", f"Restored to:\n{result}")
                else:
                    messagebox.showerror("Astrom", f"Failed to restore:\n{result}")
        self._refresh_quarantine()

    def _delete_quarantined(self):
        selected = self.quarantine_tree.selection()
        if not selected:
            return
        if not messagebox.askyesno("Astrom", "Permanently delete selected files?"):
            return
        for s in selected:
            vals = self.quarantine_tree.item(s)["values"]
            items = self.scanner.get_quarantine_list()
            match = next((i for i in items if i["filename"] == str(vals[0])), None)
            if match:
                self.scanner.delete_quarantined(match["quarantine_path"])
        self._refresh_quarantine()

    # ── Log ───────────────────────────────────────────────────────────────────

    def _refresh_log(self):
        for item in self.log_tree.get_children():
            self.log_tree.delete(item)
        for entry in reversed(self.scanner.get_threat_log()):
            self.log_tree.insert("", "end", values=(
                entry.get("timestamp", "")[:19],
                Path(entry.get("filepath", "")).name,
                entry.get("threat_name", ""),
                entry.get("detection_method", ""),
                (entry.get("file_hash") or "")[:16] + "…",
            ))


def main():
    app = AstromApp()
    app.mainloop()


if __name__ == "__main__":
    main()
