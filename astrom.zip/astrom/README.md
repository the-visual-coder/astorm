<div align="center">

# ⬡ ASTROM
### Open-source Windows Antivirus

![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)
![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

A real, functional antivirus for Windows — hash-based detection, heuristic scanning, real-time monitoring, quarantine system, and a system tray.

</div>

---

## Features

| Feature | Description |
|---|---|
| **Hash Detection** | SHA256 matching against a known malware database |
| **Heuristic Scanning** | Multi-category behavioral analysis (process injection, persistence, obfuscation, C2) |
| **Entropy Analysis** | Detects packed/encrypted executables (ransomware, crypters) |
| **Real-Time Monitor** | Watches folders live — auto-scans any new or modified file |
| **Quarantine** | Safely isolates threats, with restore and permanent delete options |
| **Whitelist** | Right-click any file to permanently whitelist it by hash |
| **System Tray** | Runs in background, minimizes to tray |
| **Threat Log** | Full JSON log of every detection |

---

## Installation

### Option A — Run from source (requires Python)

```bash
git clone https://github.com/YOUR_USERNAME/astrom.git
cd astrom
pip install -r requirements.txt
```

Then double-click **`launch.bat`** or run:

```bash
pythonw astrom.py
```

### Option B — Standalone .exe (no Python needed)

Download **`Astrom.exe`** from the [Releases](../../releases) page and run it directly.

> ⚠️ Windows may show a SmartScreen warning since Astrom isn't code-signed yet. Click "More info" → "Run anyway".

---

## Building the .exe yourself

```bash
pip install pyinstaller
build.bat
```

Output will be in the `dist\` folder.

---

## How detection works

Astrom uses three layers:

1. **SHA256 hash matching** — checks every file against a database of known malware hashes. Most reliable, zero false positives.

2. **Multi-category heuristics** — scans executable files for suspicious patterns grouped into categories: process injection, privilege escalation, persistence, obfuscation, network C2, and self-deletion. A file must match patterns from **2 or more categories** to be flagged, which drastically reduces false positives.

3. **Entropy analysis** — detects files with suspiciously high entropy (above 7.2 bits/byte), which indicates packed or encrypted payloads commonly used by ransomware and trojans.

Trusted directories (`C:\Windows\`, `C:\Program Files\`) and common legitimate filenames are always skipped from heuristic scanning.

---

## Adding malware signatures

Edit `definitions/hashes.json`:

```json
{
  "SHA256_HASH_HERE": "Malware.ThreatName"
}
```

Get hashes from:
- [MalwareBazaar](https://bazaar.abuse.ch) — free malware hash feed
- [VirusTotal](https://www.virustotal.com) — lookup & download hashes
- [abuse.ch](https://abuse.ch) — threat intelligence feeds

---

## Testing

Use the **EICAR test file** — a safe, industry-standard antivirus test string:

1. Download from [eicar.org](https://www.eicar.org/download-anti-malware-testfile/)
2. Scan it with Astrom
3. It should be detected as `EICAR-Test-File`

---

## Project structure

```
astrom/
├── astrom.py               # Entry point
├── launch.bat              # Double-click to run
├── build.bat               # Builds Astrom.exe with PyInstaller
├── requirements.txt
│
├── engine/
│   ├── scanner.py          # Core engine (hash + heuristics + entropy)
│   └── monitor.py          # Real-time filesystem monitor
│
├── gui/
│   └── app.py              # GUI + system tray
│
├── definitions/
│   └── hashes.json         # Malware SHA256 database
│
├── quarantine/             # Isolated threats stored here
└── logs/
    └── threats.log         # JSON threat log
```

---

## Roadmap

- [ ] Auto-update signature database from online feed
- [ ] VirusTotal API integration
- [ ] Scheduled scans
- [ ] Process monitor (scan running processes)
- [ ] Registry monitor (detect autorun key changes)
- [ ] YARA rule support
- [ ] Code signing

---

## Disclaimer

Astrom is an open-source project for educational and personal use. It is not a replacement for a commercial antivirus. Always keep your signature database updated.

---

## License

MIT — free to use, modify, and distribute.
