"""
Astrom Antivirus - Entry Point
Run this file to launch the application.
"""

import sys
from pathlib import Path

# Ensure project root is in path
sys.path.insert(0, str(Path(__file__).parent))

from gui.app import main

if __name__ == "__main__":
    main()
